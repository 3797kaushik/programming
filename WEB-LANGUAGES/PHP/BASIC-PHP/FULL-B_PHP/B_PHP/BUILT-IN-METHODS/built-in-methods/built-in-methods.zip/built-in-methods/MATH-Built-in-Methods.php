<link href='https://fonts.googleapis.com/css?family=Montez' rel='stylesheet' type='text/css'>
<link href='style.css' type='text/css' rel='stylesheet'/>
<?php
echo "<h1><span>Math Predefined Constant Methods  in PHP</span></h1><div>";
echo 'PI Value 180&deg; in Radians = ',M_PI,'<br>';
echo 'SQRT of 2 = ',M_SQRT2,'<br>';
echo 'SQRT of 1/2 = ',M_SQRT1_2,'<br>';
echo 'Eulers Constant = ',M_E,'<br>';
echo 'Natrual Log of 2 = ',M_LN2,'<br>';
echo 'Natrual Log of 10 = ',M_LN10,'<br>';
echo 'Log Base 2 Of Eulers Constant = ',M_LOG2E,'<br>';
echo 'Log Base 10 Of Eulers Constant = ',M_LOG10E,'<br>';
echo '</div>';


echo "<h1><span>Math User Defined Methods  in PHP</span></h1><div>";
echo 'Absolute Value = ',abs(-90),'<br>';
echo 'Exponent Value = ',exp(9),'<br>';
echo 'sqrt of 625 = ',sqrt(625),'<br>';
echo 'pow 2<sup>3</sup> = ',pow(2,3),'<br>';
echo 'Min Value = ',min(2,3,4),'<br>';
echo 'Max Value = ',max(4353.234,4353.244,4353.254),'<br>';
echo 'Floor Value = ',floor(2343.99999),'<br>';
echo 'Ceil Value = ',ceil(2343.0001),'<br>';
echo 'Round Value = ',round(2343.5001),'<br>';
echo 'Round Value = ',round(2343.5151,2),'<br>';
echo 'deg2rad 180&deg; = ',deg2rad(180),'<br>';
echo 'deg2rad 90&deg; = ',deg2rad(90),'<br>';
echo 'deg2rad 45&deg; = ',deg2rad(45),'<br>';
echo 'deg2rad 60&deg; = ',deg2rad(60),'<br>';
echo 'rad2deg = ',rad2deg(3.1415926535898),'&deg;<br>';
echo 'rad2deg = ',rad2deg(1.0471975511966),'&deg;<br>';
echo 'Sin 90&deg; = ',sin(1.5707963267949),'<br>';
echo 'tan 45&deg; = ',tan(0.78539816339745),'<br>';
echo 'cos 60&deg; = ',cos(1.0471975511966),'<br>';
echo 'Random Value = ',rand(1,5),'<br>';
echo '</div>';
?>
<pre>
















</pre>